
char *controller_cert_fingerprint = "8823a49cafe9f1c97e590ced33adef44da501ddf";
