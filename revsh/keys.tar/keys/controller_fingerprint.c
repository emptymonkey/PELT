char *controller_fingerprint_str = "8823a49cafe9f1c97e590ced33adef44da501ddf";
